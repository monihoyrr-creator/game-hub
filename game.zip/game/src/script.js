const modal = document.getElementById("gameModal");
const gameArea = document.getElementById("gameArea");
const gameTitle = document.getElementById("gameTitle");
const closeGame = document.getElementById("closeGame");

let gameInterval = null;
let animationFrame = null;

document.querySelectorAll(".play-btn").forEach(function(button) {
  button.addEventListener("click", function() {
    openGame(button.dataset.game);
  });
});

closeGame.addEventListener("click", function() {
  stopGame();
  modal.style.display = "none";
  gameArea.innerHTML = "";
});

function stopGame() {
  if (gameInterval) {
    clearInterval(gameInterval);
    gameInterval = null;
  }

  if (animationFrame) {
    cancelAnimationFrame(animationFrame);
    animationFrame = null;
  }

  document.onkeydown = null;
  document.onkeyup = null;
}

function openGame(game) {
  stopGame();

  modal.style.display = "flex";

  const titles = {
    battle: "⚔️ Battle Clicker",
    space: "🚀 Space Shooter",
    road: "🏎️ Road Dodge",
    zombie: "🧟 Zombie Clicker",
    archer: "🏹 Archer Quest",
    snake: "🐍 Snake Challenge",
    brick: "🧱 Brick Breaker",
    memory: "🧠 Memory Match",
    mole: "🎯 Whack Mole",
    guess: "🔢 Number Guess",
    reaction: "⚡ Reaction Test",
    stars: "⭐ Catch Stars",
    runner: "🥷 Ninja Runner"
  };

  gameTitle.textContent = titles[game] || "Game";

  if (game === "battle") startBattle();
  if (game === "space") startSpace();
  if (game === "road") startRoad();
  if (game === "zombie") startZombie();
  if (game === "archer") startArcher();
  if (game === "snake") startSnake();
  if (game === "brick") startBrick();
  if (game === "memory") startMemory();
  if (game === "mole") startMole();
  if (game === "guess") startGuess();
  if (game === "reaction") startReaction();
  if (game === "stars") startStars();
  if (game === "runner") startRunner();
}


/* =========================
   BATTLE CLICKER
========================= */

function startBattle() {
  gameArea.innerHTML = `
    <div class="big-game-text">
      ⚔️ Enemy HP: <span id="enemyHP">100</span>
    </div>

    <div class="score">
      Score: <span id="battleScore">0</span>
    </div>

    <button class="game-button" id="attackButton">
      ⚔️ ATTACK
    </button>

    <p id="battleMessage">
      Defeat the enemy!
    </p>
  `;

  let hp = 100;
  let score = 0;

  document.getElementById("attackButton").onclick = function() {
    hp -= Math.floor(Math.random() * 15) + 5;
    score += 10;

    document.getElementById("enemyHP").textContent =
      Math.max(0, hp);

    document.getElementById("battleScore").textContent =
      score;

    if (hp <= 0) {
      document.getElementById("battleMessage").textContent =
        "🏆 YOU WIN!";

      this.disabled = true;
    }
  };
}


/* =========================
   ZOMBIE CLICKER
========================= */

function startZombie() {
  gameArea.innerHTML = `
    <div class="score">
      Score: <span id="zScore">0</span>
    </div>

    <div class="score">
      Time: <span id="zTime">20</span>
    </div>

    <div id="zombieBox" style="
      height:300px;
      position:relative;
      background:#080808;
      border-radius:15px;
      overflow:hidden;
    "></div>

    <p id="zMessage">
      Click the zombies!
    </p>
  `;

  const box = document.getElementById("zombieBox");

  let score = 0;
  let time = 20;

  function createZombie() {
    box.innerHTML = "";

    const zombie = document.createElement("button");

    zombie.textContent = "🧟";
    zombie.style.position = "absolute";
    zombie.style.fontSize = "50px";
    zombie.style.background = "none";
    zombie.style.border = "none";
    zombie.style.cursor = "pointer";

    zombie.style.left = Math.random() * 80 + "%";
    zombie.style.top = Math.random() * 75 + "%";

    zombie.onclick = function() {
      score++;

      document.getElementById("zScore").textContent =
        score;

      createZombie();
    };

    box.appendChild(zombie);
  }

  createZombie();

  gameInterval = setInterval(function() {
    time--;

    document.getElementById("zTime").textContent =
      time;

    if (time <= 0) {
      stopGame();

      box.innerHTML = "";

      document.getElementById("zMessage").textContent =
        "🧟 Game Over! Score: " + score;
    }
  }, 1000);

  setInterval(function() {
    if (time > 0) {
      createZombie();
    }
  }, 1200);
}


/* =========================
   SNAKE
========================= */

function startSnake() {
  gameArea.innerHTML = `
    <div class="score">
      Score: <span id="snakeScore">0</span>
    </div>

    <canvas
      id="snakeCanvas"
      class="game-canvas"
      width="400"
      height="400">
    </canvas>

    <p>
      Use the arrow keys to move.
    </p>

    <p id="snakeMessage">
      Press an arrow key to start!
    </p>
  `;

  const canvas =
    document.getElementById("snakeCanvas");

  const ctx = canvas.getContext("2d");

  let snake = [
    { x: 200, y: 200 },
    { x: 180, y: 200 },
    { x: 160, y: 200 }
  ];

  let food = createFood();
  let direction = null;
  let score = 0;
  let running = true;

  function createFood() {
    return {
      x: Math.floor(Math.random() * 20) * 20,
      y: Math.floor(Math.random() * 20) * 20
    };
  }

  function draw() {
    ctx.fillStyle = "#050505";
    ctx.fillRect(0, 0, 400, 400);

    ctx.fillStyle = "red";
    ctx.fillRect(food.x, food.y, 20, 20);

    ctx.fillStyle = "lime";

    snake.forEach(function(part) {
      ctx.fillRect(
        part.x,
        part.y,
        18,
        18
      );
    });
  }

  function move() {
    if (!running || direction === null) {
      return;
    }

    let head = { ...snake[0] };

    if (direction === "UP") head.y -= 20;
    if (direction === "DOWN") head.y += 20;
    if (direction === "LEFT") head.x -= 20;
    if (direction === "RIGHT") head.x += 20;

    if (
      head.x < 0 ||
      head.x >= 400 ||
      head.y < 0 ||
      head.y >= 400
    ) {
      gameOver();
      return;
    }

    for (let part of snake) {
      if (
        head.x === part.x &&
        head.y === part.y
      ) {
        gameOver();
        return;
      }
    }

    snake.unshift(head);

    if (
      head.x === food.x &&
      head.y === food.y
    ) {
      score++;

      document.getElementById("snakeScore").textContent =
        score;

      food = createFood();
    } else {
      snake.pop();
    }

    draw();
  }

  function gameOver() {
    running = false;

    document.getElementById("snakeMessage").textContent =
      "💀 Game Over! Score: " + score;

    clearInterval(gameInterval);
  }

  document.onkeydown = function(event) {
    if (!running) return;

    if (
      event.key === "ArrowUp" &&
      direction !== "DOWN"
    ) {
      direction = "UP";
    }

    if (
      event.key === "ArrowDown" &&
      direction !== "UP"
    ) {
      direction = "DOWN";
    }

    if (
      event.key === "ArrowLeft" &&
      direction !== "RIGHT"
    ) {
      direction = "LEFT";
    }

    if (
      event.key === "ArrowRight" &&
      direction !== "LEFT"
    ) {
      direction = "RIGHT";
    }
  };

  draw();

  gameInterval = setInterval(move, 150);
}


/* =========================
   NUMBER GUESS
========================= */

function startGuess() {
  const secret =
    Math.floor(Math.random() * 100) + 1;

  let attempts = 0;

  gameArea.innerHTML = `
    <p>
      Guess a number between 1 and 100.
    </p>

    <input
      id="guessInput"
      class="guess-input"
      type="number"
      min="1"
      max="100"
      placeholder="Number">

    <button
      class="game-button"
      id="guessButton">
      GUESS
    </button>

    <p id="guessMessage">
      Make your first guess!
    </p>
  `;

  document.getElementById("guessButton").onclick =
    function() {

      const guess =
        Number(
          document.getElementById(
            "guessInput"
          ).value
        );

      attempts++;

      const message =
        document.getElementById(
          "guessMessage"
        );

      if (!guess) {
        message.textContent =
          "Please enter a number.";
      }
      else if (guess < secret) {
        message.textContent =
          "⬆️ Too low!";
      }
      else if (guess > secret) {
        message.textContent =
          "⬇️ Too high!";
      }
      else {
        message.textContent =
          "🏆 Correct! You got it in " +
          attempts +
          " attempts!";
      }
    };
}


/* =========================
   MEMORY MATCH
========================= */

function startMemory() {
  const symbols = [
    "🍎","🍎",
    "🍌","🍌",
    "🍕","🍕",
    "🚀","🚀",
    "🐱","🐱",
    "⚽","⚽",
    "⭐","⭐",
    "🎮","🎮"
  ];

  symbols.sort(
    () => Math.random() - 0.5
  );

  gameArea.innerHTML = `
    <div class="score">
      Matches:
      <span id="memoryScore">0</span>/8
    </div>

    <div
      class="memory-grid"
      id="memoryGrid">
    </div>
  `;

  const grid =
    document.getElementById("memoryGrid");

  let first = null;
  let second = null;
  let locked = false;
  let matches = 0;

  symbols.forEach(function(symbol) {

    const card =
      document.createElement("button");

    card.className = "memory-card";
    card.textContent = "❓";

    card.onclick = function() {

      if (locked || card === first) {
        return;
      }

      card.textContent = symbol;

      if (!first) {
        first = card;
        return;
      }

      second = card;
      locked = true;

      if (
        first.textContent ===
        second.textContent
      ) {

        matches++;

        document.getElementById(
          "memoryScore"
        ).textContent = matches;

        first = null;
        second = null;
        locked = false;

      } else {

        setTimeout(function() {

          first.textContent = "❓";
          second.textContent = "❓";

          first = null;
          second = null;
          locked = false;

        }, 700);
      }
    };

    grid.appendChild(card);
  });
}


/* =========================
   WHACK MOLE
========================= */

function startMole() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="moleScore">0</span>
    </div>

    <div
      class="mole-grid"
      id="moleGrid">
    </div>

    <p id="moleTime">
      Time: 20
    </p>
  `;

  const grid =
    document.getElementById("moleGrid");

  let score = 0;
  let time = 20;
  let molePosition = -1;

  for (let i = 0; i < 9; i++) {

    const hole =
      document.createElement("button");

    hole.className = "hole";
    hole.textContent = "🕳️";

    hole.onclick = function() {

      if (i === molePosition) {

        score++;

        document.getElementById(
          "moleScore"
        ).textContent = score;

        moveMole();
      }
    };

    grid.appendChild(hole);
  }

  const holes =
    document.querySelectorAll(".hole");

  function moveMole() {

    holes.forEach(function(hole) {
      hole.textContent = "🕳️";
    });

    molePosition =
      Math.floor(Math.random() * 9);

    holes[molePosition].textContent =
      "🐹";
  }

  moveMole();

  gameInterval = setInterval(function() {

    time--;

    document.getElementById(
      "moleTime"
    ).textContent =
      "Time: " + time;

    if (time <= 0) {

      clearInterval(gameInterval);

      holes.forEach(function(hole) {
        hole.textContent = "❌";
      });

      document.getElementById(
        "moleTime"
      ).textContent =
        "Game Over! Score: " + score;
    }

  }, 1000);
}


/* =========================
   REACTION TEST
========================= */

function startReaction() {
  gameArea.innerHTML = `
    <div
      id="reactionBox"
      class="reaction-box">
      CLICK TO START
    </div>

    <p id="reactionMessage">
      Test your reaction speed!
    </p>
  `;

  const box =
    document.getElementById(
      "reactionBox"
    );

  const message =
    document.getElementById(
      "reactionMessage"
    );

  let waiting = false;
  let startTime = 0;
  let timer = null;

  box.onclick = function() {

    if (waiting) {

      const result =
        Date.now() - startTime;

      waiting = false;

      message.textContent =
        "⚡ Your reaction time: " +
        result +
        " ms";

      box.textContent =
        "CLICK TO TRY AGAIN";

      box.style.background =
        "#333";

      return;
    }

    box.textContent =
      "WAIT...";

    box.style.background =
      "#992222";

    timer = setTimeout(function() {

      waiting = true;
      startTime = Date.now();

      box.textContent =
        "CLICK NOW! ⚡";

      box.style.background =
        "#228822";

    }, Math.random() * 3000 + 1000);
  };
}


/* =========================
   ARCHER
========================= */

function startArcher() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="archerScore">0</span>
    </div>

    <div
      id="archerTarget"
      style="
        height:250px;
        display:flex;
        justify-content:center;
        align-items:center;
        background:#17172a;
        border-radius:15px;
        font-size:70px;
        cursor:pointer;
      ">
      🎯
    </div>

    <p id="archerMessage">
      Hit the target!
    </p>
  `;

  let score = 0;
  let time = 20;

  const target =
    document.getElementById(
      "archerTarget"
    );

  target.onclick = function() {

    score++;

    document.getElementById(
      "archerScore"
    ).textContent = score;

    target.style.justifyContent =
      ["flex-start","center","flex-end"][
        Math.floor(Math.random() * 3)
      ];

    target.style.alignItems =
      ["flex-start","center","flex-end"][
        Math.floor(Math.random() * 3)
      ];
  };

  gameInterval = setInterval(function() {

    time--;

    document.getElementById(
      "archerMessage"
    ).textContent =
      "Time: " + time;

    if (time <= 0) {

      clearInterval(gameInterval);

      target.textContent = "🏆";

      document.getElementById(
        "archerMessage"
      ).textContent =
        "Finished! Score: " + score;
    }

  }, 1000);
}


/* =========================
   SPACE SHOOTER
========================= */

function startSpace() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="spaceScore">0</span>
    </div>

    <canvas
      id="spaceCanvas"
      class="game-canvas"
      width="500"
      height="400">
    </canvas>

    <p>
      ← → to move | SPACE to shoot
    </p>
  `;

  const canvas =
    document.getElementById(
      "spaceCanvas"
    );

  const ctx =
    canvas.getContext("2d");

  let playerX = 230;
  let bullets = [];
  let enemies = [];
  let keys = {};
  let score = 0;
  let running = true;

  document.onkeydown = function(e) {

    keys[e.key] = true;

    if (e.code === "Space") {

      bullets.push({
        x: playerX + 18,
        y: 350
      });
    }
  };

  document.onkeyup = function(e) {
    keys[e.key] = false;
  };

  const enemyTimer =
    setInterval(function() {

      enemies.push({
        x: Math.random() * 460,
        y: -30
      });

    }, 900);

  gameInterval = enemyTimer;

  function game() {

    if (!running) {
      clearInterval(enemyTimer);
      return;
    }

    ctx.fillStyle = "#020208";
    ctx.fillRect(
      0,
      0,
      500,
      400
    );

    if (keys["ArrowLeft"]) {
      playerX -= 5;
    }

    if (keys["ArrowRight"]) {
      playerX += 5;
    }

    playerX =
      Math.max(
        0,
        Math.min(460, playerX)
      );

    ctx.font = "35px Arial";

    ctx.fillText(
      "🚀",
      playerX,
      380
    );

    bullets.forEach(function(bullet) {

      bullet.y -= 8;

      ctx.fillStyle = "yellow";

      ctx.fillRect(
        bullet.x,
        bullet.y,
        5,
        15
      );
    });

    enemies.forEach(function(enemy) {

      enemy.y += 2;

      ctx.font = "30px Arial";

      ctx.fillText(
        "👾",
        enemy.x,
        enemy.y
      );

      if (enemy.y > 400) {
        running = false;
      }
    });

    bullets.forEach(function(bullet) {

      enemies.forEach(function(enemy) {

        if (
          bullet.x > enemy.x &&
          bullet.x < enemy.x + 30 &&
          bullet.y > enemy.y - 30 &&
          bullet.y < enemy.y
        ) {

          enemy.y = 1000;
          bullet.y = -100;

          score++;

          document.getElementById(
            "spaceScore"
          ).textContent = score;
        }
      });
    });

    if (!running) {

      ctx.font = "35px Arial";

      ctx.fillStyle = "white";

      ctx.fillText(
        "GAME OVER",
        170,
        200
      );

      clearInterval(enemyTimer);

      return;
    }

    animationFrame =
      requestAnimationFrame(game);
  }

  game();
}


/* =========================
   ROAD DODGE
========================= */

function startRoad() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="roadScore">0</span>
    </div>

    <canvas
      id="roadCanvas"
      class="game-canvas"
      width="400"
      height="500">
    </canvas>

    <p>
      Use ← and → to move
    </p>
  `;

  const canvas =
    document.getElementById(
      "roadCanvas"
    );

  const ctx =
    canvas.getContext("2d");

  let playerX = 180;
  let cars = [];
  let keys = {};
  let score = 0;
  let running = true;

  document.onkeydown = function(e) {
    keys[e.key] = true;
  };

  document.onkeyup = function(e) {
    keys[e.key] = false;
  };

  gameInterval = setInterval(function() {

    cars.push({
      x: Math.random() * 360,
      y: -50
    });

  }, 900);

  function game() {

    if (!running) {
      return;
    }

    ctx.fillStyle = "#333";
    ctx.fillRect(
      0,
      0,
      400,
      500
    );

    if (keys["ArrowLeft"]) {
      playerX -= 6;
    }

    if (keys["ArrowRight"]) {
      playerX += 6;
    }

    playerX =
      Math.max(
        0,
        Math.min(360, playerX)
      );

    ctx.font = "40px Arial";

    ctx.fillText(
      "🏎️",
      playerX,
      470
    );

    cars.forEach(function(car) {

      car.y += 4;

      ctx.fillText(
        "🚗",
        car.x,
        car.y
      );

      if (
        playerX < car.x + 40 &&
        playerX + 40 > car.x &&
        430 < car.y + 60 &&
        480 > car.y
      ) {
        running = false;
      }
    });

    score++;

    document.getElementById(
      "roadScore"
    ).textContent =
      Math.floor(score / 10);

    if (!running) {

      clearInterval(gameInterval);

      ctx.font = "35px Arial";

      ctx.fillText(
        "GAME OVER",
        100,
        250
      );

      return;
    }

    animationFrame =
      requestAnimationFrame(game);
  }

  game();
}


/* =========================
   BRICK BREAKER
========================= */

function startBrick() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="brickScore">0</span>
    </div>

    <canvas
      id="brickCanvas"
      class="game-canvas"
      width="500"
      height="400">
    </canvas>

    <p>
      Use ← and → to move
    </p>
  `;

  const canvas =
    document.getElementById(
      "brickCanvas"
    );

  const ctx =
    canvas.getContext("2d");

  let ball = {
    x: 250,
    y: 300,
    dx: 3,
    dy: -3
  };

  let paddle = {
    x: 210,
    y: 370,
    width: 80
  };

  let bricks = [];

  for (let row = 0; row < 4; row++) {

    for (let col = 0; col < 8; col++) {

      bricks.push({
        x: col * 62 + 3,
        y: row * 30 + 20,
        alive: true
      });
    }
  }

  let keys = {};
  let score = 0;
  let running = true;

  document.onkeydown = function(e) {
    keys[e.key] = true;
  };

  document.onkeyup = function(e) {
    keys[e.key] = false;
  };

  function game() {

    if (!running) return;

    ctx.fillStyle = "#050508";

    ctx.fillRect(
      0,
      0,
      500,
      400
    );

    if (keys["ArrowLeft"]) {
      paddle.x -= 6;
    }

    if (keys["ArrowRight"]) {
      paddle.x += 6;
    }

    paddle.x =
      Math.max(
        0,
        Math.min(
          420,
          paddle.x
        )
      );

    ball.x += ball.dx;
    ball.y += ball.dy;

    if (
      ball.x < 0 ||
      ball.x > 500
    ) {
      ball.dx *= -1;
    }

    if (ball.y < 0) {
      ball.dy *= -1;
    }

    if (
      ball.y > 360 &&
      ball.x > paddle.x &&
      ball.x < paddle.x + paddle.width
    ) {
      ball.dy = -Math.abs(ball.dy);
    }

    if (ball.y > 400) {
      running = false;
    }

    bricks.forEach(function(brick) {

      if (!brick.alive) return;

      if (
        ball.x > brick.x &&
        ball.x < brick.x + 58 &&
        ball.y > brick.y &&
        ball.y < brick.y + 20
      ) {

        brick.alive = false;
        ball.dy *= -1;

        score++;

        document.getElementById(
          "brickScore"
        ).textContent = score;
      }

      if (brick.alive) {

        ctx.fillStyle = "#7c3cff";

        ctx.fillRect(
          brick.x,
          brick.y,
          58,
          20
        );
      }
    });

    ctx.fillStyle = "white";

    ctx.beginPath();

    ctx.arc(
      ball.x,
      ball.y,
      8,
      0,
      Math.PI * 2
    );

    ctx.fill();

    ctx.fillStyle = "#00ffff";

    ctx.fillRect(
      paddle.x,
      paddle.y,
      paddle.width,
      10
    );

    if (score === bricks.length) {

      running = false;

      ctx.font = "35px Arial";

      ctx.fillText(
        "YOU WIN!",
        185,
        250
      );

      return;
    }

    if (!running) {

      ctx.font = "35px Arial";

      ctx.fillText(
        "GAME OVER",
        165,
        250
      );

      return;
    }

    animationFrame =
      requestAnimationFrame(game);
  }

  game();
}


/* =========================
   CATCH STARS
========================= */

function startStars() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="starScore">0</span>
    </div>

    <canvas
      id="starCanvas"
      class="game-canvas"
      width="400"
      height="500">
    </canvas>

    <p>
      Use ← and → to catch ⭐
    </p>
  `;

  const canvas =
    document.getElementById(
      "starCanvas"
    );

  const ctx =
    canvas.getContext("2d");

  let playerX = 175;
  let stars = [];
  let keys = {};
  let score = 0;

  document.onkeydown = function(e) {
    keys[e.key] = true;
  };

  document.onkeyup = function(e) {
    keys[e.key] = false;
  };

  gameInterval = setInterval(function() {

    stars.push({
      x: Math.random() * 370,
      y: -20,
      speed: 2 + Math.random() * 3
    });

  }, 700);

  function game() {

    ctx.fillStyle = "#05050d";

    ctx.fillRect(
      0,
      0,
      400,
      500
    );

    if (keys["ArrowLeft"]) {
      playerX -= 6;
    }

    if (keys["ArrowRight"]) {
      playerX += 6;
    }

    playerX =
      Math.max(
        0,
        Math.min(350, playerX)
      );

    ctx.font = "40px Arial";

    ctx.fillText(
      "🧺",
      playerX,
      470
    );

    stars.forEach(function(star) {

      star.y += star.speed;

      ctx.fillText(
        "⭐",
        star.x,
        star.y
      );

      if (
        star.y > 430 &&
        star.x > playerX - 20 &&
        star.x < playerX + 60
      ) {

        star.y = 1000;

        score++;

        document.getElementById(
          "starScore"
        ).textContent = score;
      }
    });

    animationFrame =
      requestAnimationFrame(game);
  }

  game();
}


/* =========================
   NINJA RUNNER
========================= */

function startRunner() {
  gameArea.innerHTML = `
    <div class="score">
      Score:
      <span id="runnerScore">0</span>
    </div>

    <canvas
      id="runnerCanvas"
      class="game-canvas"
      width="500"
      height="300">
    </canvas>

    <button
      class="game-button"
      id="jumpButton">
      JUMP 🥷
    </button>

    <p>
      Press SPACE or JUMP
    </p>
  `;

  const canvas =
    document.getElementById(
      "runnerCanvas"
    );

  const ctx =
    canvas.getContext("2d");

  let playerY = 220;
  let velocity = 0;
  let jumping = false;

  let obstacleX = 500;

  let score = 0;
  let running = true;

  function jump() {

    if (!jumping) {

      velocity = -11;
      jumping = true;
    }
  }

  document.getElementById(
    "jumpButton"
  ).onclick = jump;

  document.onkeydown = function(e) {

    if (e.code === "Space") {
      jump();
    }
  };

  function game() {

    if (!running) return;

    ctx.fillStyle = "#17172b";

    ctx.fillRect(
      0,
      0,
      500,
      300
    );

    ctx.fillStyle = "#444";

    ctx.fillRect(
      0,
      270,
      500,
      30
    );

    velocity += 0.5;
    playerY += velocity;

    if (playerY >= 220) {

      playerY = 220;
      velocity = 0;
      jumping = false;
    }

    obstacleX -= 5;

    if (obstacleX < -50) {

      obstacleX = 500;
      score++;

      document.getElementById(
        "runnerScore"
      ).textContent = score;
    }

    ctx.font = "45px Arial";

    ctx.fillText(
      "🥷",
      60,
      playerY + 40
    );

    ctx.font = "35px Arial";

    ctx.fillText(
      "🪨",
      obstacleX,
      270
    );

    if (
      60 < obstacleX + 30 &&
      100 > obstacleX &&
      playerY + 50 > 235
    ) {

      running = false;

      ctx.font = "35px Arial";

      ctx.fillText(
        "GAME OVER",
        160,
        150
      );

      return;
    }

    animationFrame =
      requestAnimationFrame(game);
  }

  game();
}